| `Version` | `Comment`                                                       |
|-----------|-----------------------------------------------------------------|
| 1.0.1     | - Event driven update of blacklist array when config is changed |
| 1.0.0     | - Initial release                                               |
